<div class="extension-demo">
	Welcome to dcat-admin !
</div>

<style>
	.extension-demo {
		color: @primary;
	}
</style>

<script require="@dcat-admin.operation-log">
	$('.extension-demo').extensionDemo();
</script>
